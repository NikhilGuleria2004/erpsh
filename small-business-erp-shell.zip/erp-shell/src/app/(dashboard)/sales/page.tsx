"use client";

import { useMemo, useState } from "react";
import { ShoppingCart, TrendingUp, Package, CircleCheck } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { Card } from "@/components/ui/Card";
import { SearchInput } from "@/components/ui/Input";
import { StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { QuickFormModal } from "@/components/forms/QuickFormModal";
import { salesOrders } from "@/mock/sales";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { SalesOrder } from "@/types";

const total = salesOrders.reduce((sum, o) => sum + o.amount, 0);
const fulfilled = salesOrders.filter((o) => o.status === "fulfilled").length;
const avgOrder = Math.round(total / salesOrders.length);

export default function SalesPage() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(
    () =>
      salesOrders.filter(
        (o) =>
          o.id.toLowerCase().includes(query.toLowerCase()) ||
          o.customerName.toLowerCase().includes(query.toLowerCase())
      ),
    [query]
  );

  const columns: Column<SalesOrder>[] = [
    { header: "Order ID", render: (r) => <span className="font-medium">{r.id}</span> },
    { header: "Customer", render: (r) => r.customerName },
    { header: "Items", align: "right", render: (r) => r.itemsCount },
    { header: "Amount", align: "right", render: (r) => <span className="tabular-nums">{formatCurrency(r.amount)}</span> },
    { header: "Date", render: (r) => formatDate(r.date) },
    { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <>
      <PageHeader
        title="Sales"
        description="Orders placed by customers and their fulfillment status."
        actions={
          <QuickFormModal
            triggerLabel="Create sale"
            title="Create sale"
            description="Start a new sales order for a customer."
            fields={[
              { label: "Customer", placeholder: "Search customer..." },
              { label: "Product", placeholder: "Search product..." },
              { label: "Quantity", type: "number", placeholder: "1" },
            ]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total sales" value={formatCurrency(total)} icon={TrendingUp} />
        <StatCard label="Orders" value={String(salesOrders.length)} icon={ShoppingCart} />
        <StatCard label="Fulfilled" value={String(fulfilled)} icon={CircleCheck} />
        <StatCard label="Average order value" value={formatCurrency(avgOrder)} icon={Package} />
      </div>

      <div className="flex items-center gap-2">
        <SearchInput
          className="max-w-xs"
          placeholder="Search by order ID or customer..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <span className="ml-auto text-[12.5px] text-text-tertiary">
          {filtered.length} of {salesOrders.length} orders
        </span>
      </div>

      <Card>
        <DataTable columns={columns} rows={filtered} getRowKey={(r) => r.id} emptyLabel="No orders match your search." />
      </Card>
    </>
  );
}
