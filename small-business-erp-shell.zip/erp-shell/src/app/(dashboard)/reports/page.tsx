import { TrendingUp, Boxes, Receipt, CircleDollarSign, Users, ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, CardBody } from "@/components/ui/Card";
import { formatCurrency } from "@/lib/utils";

const REPORTS = [
  {
    title: "Sales report",
    description: "Revenue broken down by day, product, category, and customer.",
    icon: TrendingUp,
    stat: { label: "This month", value: formatCurrency(1250000) },
  },
  {
    title: "Inventory report",
    description: "Current stock levels, valuation, and slow-moving products.",
    icon: Boxes,
    stat: { label: "Inventory value", value: formatCurrency(3480000) },
  },
  {
    title: "Expense report",
    description: "Operating costs grouped by category over any date range.",
    icon: Receipt,
    stat: { label: "This month", value: formatCurrency(420000) },
  },
  {
    title: "Profit report",
    description: "Revenue minus cost of goods and operating expenses.",
    icon: CircleDollarSign,
    stat: { label: "Net profit", value: formatCurrency(830000) },
  },
  {
    title: "Customer report",
    description: "Purchase frequency, lifetime value, and outstanding balances.",
    icon: Users,
    stat: { label: "Active customers", value: "523" },
  },
];

export default function ReportsPage() {
  return (
    <>
      <PageHeader
        title="Reports"
        description="Pick a report to see business performance from a different angle."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {REPORTS.map((report) => {
          const Icon = report.icon;
          return (
            <Card
              key={report.title}
              className="group cursor-pointer transition-colors hover:border-border-strong"
            >
              <CardBody className="flex flex-col gap-4">
                <div className="flex items-start justify-between">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-accent-soft">
                    <Icon className="h-4.5 w-4.5 text-accent" strokeWidth={1.75} />
                  </div>
                  <ArrowRight className="h-4 w-4 text-text-tertiary transition-transform group-hover:translate-x-0.5 group-hover:text-text-secondary" />
                </div>
                <div>
                  <h3 className="text-[14px] font-semibold text-text-primary">{report.title}</h3>
                  <p className="mt-1 text-[13px] text-text-secondary">{report.description}</p>
                </div>
                <div className="mt-1 border-t border-border pt-3">
                  <p className="text-[11.5px] text-text-tertiary">{report.stat.label}</p>
                  <p className="text-[16px] font-semibold tabular-nums text-text-primary">
                    {report.stat.value}
                  </p>
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>
    </>
  );
}
