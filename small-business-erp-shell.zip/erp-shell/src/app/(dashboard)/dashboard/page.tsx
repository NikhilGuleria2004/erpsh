import { Wallet, Receipt, TrendingUp, ShoppingCart, Boxes, CircleDollarSign } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { Card, CardHeader, CardTitle, CardBody } from "@/components/ui/Card";
import { StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { SalesTrendChart } from "@/components/dashboard/SalesTrendChart";
import { CategoryBreakdown } from "@/components/dashboard/CategoryBreakdown";
import { InventoryStatusChart } from "@/components/dashboard/InventoryStatusChart";
import { salesOrders } from "@/mock/sales";
import { purchaseOrders } from "@/mock/purchases";
import { products } from "@/mock/products";
import { formatCurrency } from "@/lib/utils";
import type { SalesOrder, PurchaseOrder, Product } from "@/types";

const recentSales = salesOrders.slice(0, 5);
const recentPurchases = purchaseOrders.slice(0, 5);
const lowStockProducts = products
  .filter((p) => p.stockQuantity <= p.minimumStockLevel)
  .sort((a, b) => a.stockQuantity - b.stockQuantity)
  .slice(0, 5);

const salesColumns: Column<SalesOrder>[] = [
  { header: "Order", render: (r) => <span className="font-medium">{r.id}</span> },
  { header: "Customer", render: (r) => r.customerName },
  { header: "Amount", align: "right", render: (r) => <span className="tabular-nums">{formatCurrency(r.amount)}</span> },
  { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

const purchaseColumns: Column<PurchaseOrder>[] = [
  { header: "PO Number", render: (r) => <span className="font-medium">{r.id}</span> },
  { header: "Supplier", render: (r) => r.supplierName },
  { header: "Amount", align: "right", render: (r) => <span className="tabular-nums">{formatCurrency(r.amount)}</span> },
  { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
];

const lowStockColumns: Column<Product>[] = [
  { header: "Product", render: (r) => <span className="font-medium">{r.name}</span> },
  { header: "SKU", render: (r) => <span className="text-text-secondary">{r.sku}</span> },
  { header: "Stock left", align: "right", render: (r) => <span className="tabular-nums text-danger">{r.stockQuantity}</span> },
  { header: "Minimum", align: "right", render: (r) => <span className="tabular-nums text-text-secondary">{r.minimumStockLevel}</span> },
];

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        title="Overview"
        description="A snapshot of sales, inventory, and cash flow across the business."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total sales" value="₹12.5L" icon={TrendingUp} trend={{ value: "8.2%", direction: "up" }} />
        <StatCard label="Total expenses" value="₹4.2L" icon={Receipt} trend={{ value: "2.1%", direction: "down" }} />
        <StatCard label="Net profit" value="₹8.3L" icon={CircleDollarSign} trend={{ value: "11.4%", direction: "up" }} />
        <StatCard label="Orders" value="1,245" icon={ShoppingCart} />
        <StatCard label="Inventory value" value="₹34.8L" icon={Boxes} />
        <StatCard label="Outstanding payments" value="₹3.1L" icon={Wallet} />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Sales over time</CardTitle>
            <span className="text-[12.5px] text-text-tertiary">Last 6 months</span>
          </CardHeader>
          <CardBody>
            <SalesTrendChart />
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales by category</CardTitle>
          </CardHeader>
          <CardBody>
            <CategoryBreakdown />
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Recent sales</CardTitle>
          </CardHeader>
          <DataTable columns={salesColumns} rows={recentSales} getRowKey={(r) => r.id} />
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Inventory status</CardTitle>
          </CardHeader>
          <CardBody>
            <InventoryStatusChart />
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Low-stock products</CardTitle>
          </CardHeader>
          <DataTable columns={lowStockColumns} rows={lowStockProducts} getRowKey={(r) => r.id} />
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent purchase orders</CardTitle>
          </CardHeader>
          <DataTable columns={purchaseColumns} rows={recentPurchases} getRowKey={(r) => r.id} />
        </Card>
      </div>
    </>
  );
}
