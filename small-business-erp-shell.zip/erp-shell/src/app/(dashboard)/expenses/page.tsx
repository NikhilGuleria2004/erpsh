"use client";

import { useMemo, useState } from "react";
import { Receipt, IndianRupee, Clock } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { Card } from "@/components/ui/Card";
import { SearchInput } from "@/components/ui/Input";
import { StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { QuickFormModal } from "@/components/forms/QuickFormModal";
import { expenses } from "@/mock/expenses";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { Expense } from "@/types";

const total = expenses.reduce((sum, e) => sum + e.amount, 0);
const pendingApproval = expenses.filter((e) => e.status === "pending_approval").length;

export default function ExpensesPage() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(
    () =>
      expenses.filter(
        (e) =>
          e.category.toLowerCase().includes(query.toLowerCase()) ||
          e.description.toLowerCase().includes(query.toLowerCase())
      ),
    [query]
  );

  const columns: Column<Expense>[] = [
    { header: "Category", render: (r) => <span className="font-medium">{r.category}</span> },
    { header: "Description", render: (r) => <span className="text-text-secondary">{r.description}</span> },
    { header: "Amount", align: "right", render: (r) => <span className="tabular-nums">{formatCurrency(r.amount)}</span> },
    { header: "Date", render: (r) => formatDate(r.date) },
    { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <>
      <PageHeader
        title="Expenses"
        description="Operating costs that aren't tied to inventory purchases."
        actions={
          <QuickFormModal
            triggerLabel="Add expense"
            title="Add expense"
            fields={[
              { label: "Category", placeholder: "e.g. Electricity" },
              { label: "Description", placeholder: "e.g. August electricity bill" },
              { label: "Amount", type: "number", placeholder: "0" },
              { label: "Date", type: "date" },
            ]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Total expenses" value={formatCurrency(total)} icon={IndianRupee} />
        <StatCard label="Entries" value={String(expenses.length)} icon={Receipt} />
        <StatCard label="Pending approval" value={String(pendingApproval)} icon={Clock} />
      </div>

      <div className="flex items-center gap-2">
        <SearchInput
          className="max-w-xs"
          placeholder="Search by category or description..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <span className="ml-auto text-[12.5px] text-text-tertiary">
          {filtered.length} of {expenses.length} expenses
        </span>
      </div>

      <Card>
        <DataTable columns={columns} rows={filtered} getRowKey={(r) => r.id} emptyLabel="No expenses match your search." />
      </Card>
    </>
  );
}
