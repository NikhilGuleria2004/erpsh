"use client";

import { useMemo, useState } from "react";
import { Truck, IndianRupee, Clock, CircleCheck } from "lucide-react";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { Card } from "@/components/ui/Card";
import { SearchInput } from "@/components/ui/Input";
import { StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { QuickFormModal } from "@/components/forms/QuickFormModal";
import { purchaseOrders } from "@/mock/purchases";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { PurchaseOrder } from "@/types";

const total = purchaseOrders.reduce((sum, o) => sum + o.amount, 0);
const pending = purchaseOrders.filter((o) => o.status === "pending" || o.status === "confirmed").length;
const received = purchaseOrders.filter((o) => o.status === "received").length;

export default function PurchasesPage() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(
    () =>
      purchaseOrders.filter(
        (o) =>
          o.id.toLowerCase().includes(query.toLowerCase()) ||
          o.supplierName.toLowerCase().includes(query.toLowerCase())
      ),
    [query]
  );

  const columns: Column<PurchaseOrder>[] = [
    { header: "PO Number", render: (r) => <span className="font-medium">{r.id}</span> },
    { header: "Supplier", render: (r) => r.supplierName },
    { header: "Items", align: "right", render: (r) => r.itemsCount },
    { header: "Amount", align: "right", render: (r) => <span className="tabular-nums">{formatCurrency(r.amount)}</span> },
    { header: "Date", render: (r) => formatDate(r.date) },
    { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <>
      <PageHeader
        title="Purchases"
        description="Purchase orders placed with suppliers and their receiving status."
        actions={
          <QuickFormModal
            triggerLabel="Create purchase order"
            title="Create purchase order"
            description="Order stock from a supplier."
            fields={[
              { label: "Supplier", placeholder: "Search supplier..." },
              { label: "Product", placeholder: "Search product..." },
              { label: "Quantity", type: "number", placeholder: "1" },
            ]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total purchases" value={formatCurrency(total)} icon={IndianRupee} />
        <StatCard label="Purchase orders" value={String(purchaseOrders.length)} icon={Truck} />
        <StatCard label="Awaiting receipt" value={String(pending)} icon={Clock} />
        <StatCard label="Fully received" value={String(received)} icon={CircleCheck} />
      </div>

      <div className="flex items-center gap-2">
        <SearchInput
          className="max-w-xs"
          placeholder="Search by PO number or supplier..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <span className="ml-auto text-[12.5px] text-text-tertiary">
          {filtered.length} of {purchaseOrders.length} orders
        </span>
      </div>

      <Card>
        <DataTable columns={columns} rows={filtered} getRowKey={(r) => r.id} emptyLabel="No purchase orders match your search." />
      </Card>
    </>
  );
}
