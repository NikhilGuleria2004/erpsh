"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { SearchInput } from "@/components/ui/Input";
import { StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { QuickFormModal } from "@/components/forms/QuickFormModal";
import { suppliers } from "@/mock/suppliers";
import { formatCurrency } from "@/lib/utils";
import type { Supplier } from "@/types";

export default function SuppliersPage() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(
    () =>
      suppliers.filter(
        (s) =>
          s.companyName.toLowerCase().includes(query.toLowerCase()) ||
          s.contactPerson.toLowerCase().includes(query.toLowerCase())
      ),
    [query]
  );

  const columns: Column<Supplier>[] = [
    { header: "Company", render: (r) => <span className="font-medium">{r.companyName}</span> },
    { header: "Contact person", render: (r) => r.contactPerson },
    { header: "Email", render: (r) => <span className="text-text-secondary">{r.email}</span> },
    { header: "Phone", render: (r) => r.phone },
    {
      header: "Outstanding balance",
      align: "right",
      render: (r) => (
        <span className={`tabular-nums ${r.outstandingBalance > 0 ? "text-warning" : "text-text-secondary"}`}>
          {formatCurrency(r.outstandingBalance)}
        </span>
      ),
    },
    { header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <>
      <PageHeader
        title="Suppliers"
        description="Vendors the business buys stock from, and what's owed to them."
        actions={
          <QuickFormModal
            triggerLabel="Add supplier"
            title="Add supplier"
            fields={[
              { label: "Company name", placeholder: "e.g. ABC Electronics" },
              { label: "Contact person", placeholder: "e.g. Suresh Rao" },
              { label: "Email", placeholder: "name@example.com" },
            ]}
          />
        }
      />

      <div className="flex items-center gap-2">
        <SearchInput
          className="max-w-xs"
          placeholder="Search by company or contact..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <span className="ml-auto text-[12.5px] text-text-tertiary">
          {filtered.length} of {suppliers.length} suppliers
        </span>
      </div>

      <Card>
        <DataTable columns={columns} rows={filtered} getRowKey={(r) => r.id} emptyLabel="No suppliers match your search." />
      </Card>
    </>
  );
}
