"use client";

import { useState } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, CardHeader, CardTitle, CardBody } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[13px] font-medium text-text-primary">{label}</span>
      {children}
    </label>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={onChange}
      className={cn(
        "relative h-5 w-9 shrink-0 rounded-full transition-colors",
        checked ? "bg-accent" : "bg-border-strong"
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform",
          checked ? "translate-x-[18px]" : "translate-x-0.5"
        )}
      />
    </button>
  );
}

const NOTIFICATION_OPTIONS = [
  { key: "lowStock", label: "Low-stock alerts", description: "When a product falls below its minimum stock level." },
  { key: "overdueInvoices", label: "Overdue invoices", description: "When a customer invoice passes its due date." },
  { key: "receivedPOs", label: "Purchase orders received", description: "When a supplier order is marked as received." },
  { key: "supplierPayments", label: "Supplier payments due", description: "A day before a scheduled supplier payment." },
];

const THEMES = ["Light", "Dark", "System"] as const;

export default function SettingsPage() {
  const [notifications, setNotifications] = useState<Record<string, boolean>>({
    lowStock: true,
    overdueInvoices: true,
    receivedPOs: true,
    supplierPayments: false,
  });
  const [theme, setTheme] = useState<(typeof THEMES)[number]>("Light");

  return (
    <>
      <PageHeader title="Settings" description="Business details, preferences, and notification rules." />

      <Card>
        <CardHeader>
          <CardTitle>Business information</CardTitle>
        </CardHeader>
        <CardBody className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Business name">
            <Input defaultValue="Ledgerly Electronics" />
          </Field>
          <Field label="Tax number">
            <Input defaultValue="29ABCDE1234F1Z5" />
          </Field>
          <Field label="Contact email">
            <Input defaultValue="hello@ledgerlyelectronics.example" />
          </Field>
          <Field label="Contact phone">
            <Input defaultValue="+91 90000 12345" />
          </Field>
          <Field label="Address">
            <Input defaultValue="12 MG Road, Bengaluru, Karnataka" />
          </Field>
          <Field label="Currency">
            <Input defaultValue="INR (₹)" disabled />
          </Field>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>User preferences</CardTitle>
        </CardHeader>
        <CardBody className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Display name">
            <Input defaultValue="Aditi Nair" />
          </Field>
          <Field label="Role">
            <Input defaultValue="Admin" disabled />
          </Field>
          <Field label="Date format">
            <Input defaultValue="DD MMM YYYY" />
          </Field>
          <Field label="Default landing page">
            <Input defaultValue="Dashboard" />
          </Field>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
        </CardHeader>
        <CardBody className="flex flex-col gap-4">
          {NOTIFICATION_OPTIONS.map((option) => (
            <div key={option.key} className="flex items-center justify-between gap-4">
              <div>
                <p className="text-[13px] font-medium text-text-primary">{option.label}</p>
                <p className="text-[12.5px] text-text-secondary">{option.description}</p>
              </div>
              <Toggle
                checked={notifications[option.key]}
                onChange={() =>
                  setNotifications((prev) => ({ ...prev, [option.key]: !prev[option.key] }))
                }
              />
            </div>
          ))}
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
        </CardHeader>
        <CardBody>
          <p className="mb-3 text-[13px] text-text-secondary">Choose how the ERP looks on this device.</p>
          <div className="flex gap-2">
            {THEMES.map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={cn(
                  "rounded-md border px-3.5 py-1.5 text-[13px] font-medium transition-colors",
                  theme === t
                    ? "border-accent bg-accent-soft text-accent"
                    : "border-border text-text-secondary hover:bg-surface-alt"
                )}
              >
                {t}
              </button>
            ))}
          </div>
        </CardBody>
      </Card>

      <div className="flex justify-end gap-2 pb-2">
        <Button variant="ghost">Discard changes</Button>
        <Button variant="primary">Save settings</Button>
      </div>
    </>
  );
}
