import { products } from "@/mock/products";

function classify(stock: number, min: number): "in_stock" | "low_stock" | "out_of_stock" {
  if (stock <= 0) return "out_of_stock";
  if (stock <= min) return "low_stock";
  return "in_stock";
}

const SEGMENTS = [
  { key: "in_stock" as const, label: "In stock", colorClass: "bg-positive" },
  { key: "low_stock" as const, label: "Low stock", colorClass: "bg-warning" },
  { key: "out_of_stock" as const, label: "Out of stock", colorClass: "bg-danger" },
];

export function InventoryStatusChart() {
  const counts = { in_stock: 0, low_stock: 0, out_of_stock: 0 };
  for (const p of products) {
    counts[classify(p.stockQuantity, p.minimumStockLevel)] += 1;
  }
  const total = products.length;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-surface-alt">
        {SEGMENTS.map((seg) => {
          const pct = (counts[seg.key] / total) * 100;
          if (pct === 0) return null;
          return (
            <div
              key={seg.key}
              className={seg.colorClass}
              style={{ width: `${pct}%` }}
              title={`${seg.label}: ${counts[seg.key]}`}
            />
          );
        })}
      </div>
      <div className="flex flex-col gap-2.5">
        {SEGMENTS.map((seg) => (
          <div key={seg.key} className="flex items-center justify-between text-[12.5px]">
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${seg.colorClass}`} />
              <span className="text-text-secondary">{seg.label}</span>
            </div>
            <span className="tabular-nums text-text-primary">{counts[seg.key]} products</span>
          </div>
        ))}
      </div>
    </div>
  );
}
