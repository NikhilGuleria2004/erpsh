import { formatCompactCurrency } from "@/lib/utils";

const CATEGORIES = [
  { label: "Laptops", value: 542000 },
  { label: "Mobile Phones", value: 398000 },
  { label: "Monitors", value: 156000 },
  { label: "Accessories", value: 87000 },
  { label: "Networking", value: 41000 },
];

export function CategoryBreakdown() {
  const max = Math.max(...CATEGORIES.map((c) => c.value));

  return (
    <div className="flex flex-col gap-3.5">
      {CATEGORIES.map((cat) => (
        <div key={cat.label} className="flex items-center gap-3">
          <span className="w-[108px] shrink-0 truncate text-[12.5px] text-text-secondary">
            {cat.label}
          </span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-surface-alt">
            <div
              className="h-full rounded-full bg-accent"
              style={{ width: `${(cat.value / max) * 100}%` }}
            />
          </div>
          <span className="w-16 shrink-0 text-right text-[12.5px] tabular-nums text-text-primary">
            {formatCompactCurrency(cat.value)}
          </span>
        </div>
      ))}
    </div>
  );
}
