import { formatCompactCurrency } from "@/lib/utils";

interface DataPoint {
  label: string;
  value: number;
}

const DATA: DataPoint[] = [
  { label: "Mar", value: 780000 },
  { label: "Apr", value: 910000 },
  { label: "May", value: 860000 },
  { label: "Jun", value: 1040000 },
  { label: "Jul", value: 980000 },
  { label: "Aug", value: 1250000 },
];

export function SalesTrendChart() {
  const max = Math.max(...DATA.map((d) => d.value));

  return (
    <div className="flex h-[190px] items-end gap-3 px-1">
      {DATA.map((point) => {
        const heightPct = Math.max((point.value / max) * 100, 4);
        return (
          <div key={point.label} className="flex flex-1 flex-col items-center gap-2">
            <div className="flex h-[140px] w-full items-end">
              <div
                className="w-full rounded-t-sm bg-accent-soft transition-[height] hover:bg-accent/25"
                style={{ height: `${heightPct}%` }}
                title={formatCompactCurrency(point.value)}
              >
                <div className="h-full w-full rounded-t-sm border-t-2 border-accent" />
              </div>
            </div>
            <span className="text-[11.5px] text-text-tertiary">{point.label}</span>
          </div>
        );
      })}
    </div>
  );
}
