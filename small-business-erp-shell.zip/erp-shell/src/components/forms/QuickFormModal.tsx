"use client";

import { useState, type ReactNode } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";

export interface QuickFormField {
  label: string;
  placeholder?: string;
  type?: "text" | "number" | "date";
}

interface QuickFormModalProps {
  triggerLabel: string;
  title: string;
  description?: string;
  fields: QuickFormField[];
  triggerIcon?: ReactNode;
}

/**
 * Opens a modal with a static form. Submitting closes the modal without
 * persisting anything — this is a UI placeholder until the real
 * create-record flow (validation, API call) is implemented.
 */
export function QuickFormModal({
  triggerLabel,
  title,
  description,
  fields,
  triggerIcon = <Plus className="h-3.5 w-3.5" />,
}: QuickFormModalProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button variant="primary" onClick={() => setOpen(true)}>
        {triggerIcon}
        {triggerLabel}
      </Button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={title}
        description={description}
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={() => setOpen(false)}>
              Save
            </Button>
          </>
        }
      >
        <form
          className="flex flex-col gap-3.5"
          onSubmit={(e) => {
            e.preventDefault();
            setOpen(false);
          }}
        >
          {fields.map((field) => (
            <label key={field.label} className="flex flex-col gap-1.5">
              <span className="text-[13px] font-medium text-text-primary">
                {field.label}
              </span>
              <Input type={field.type ?? "text"} placeholder={field.placeholder} />
            </label>
          ))}
          <p className="text-[12px] text-text-tertiary">
            This form is a UI placeholder — nothing is saved yet.
          </p>
        </form>
      </Modal>
    </>
  );
}
